﻿
namespace School
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tpgEntrance = new System.Windows.Forms.TabPage();
            this.cbxEntranceGrade = new System.Windows.Forms.ComboBox();
            this.btnEntrance = new System.Windows.Forms.Button();
            this.pnlEntranceCompany = new System.Windows.Forms.Panel();
            this.tbxEntranceCompany = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chkIndustrialEdu = new System.Windows.Forms.CheckBox();
            this.tbxEntranceName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblEntranceResult = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tpgRegCourse = new System.Windows.Forms.TabPage();
            this.tpgSearchStudent = new System.Windows.Forms.TabPage();
            this.tbxRegCourseSearchId = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblRegCourseId = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblRegCourseName = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnRegCourseSearch = new System.Windows.Forms.Button();
            this.lbxRegCourse = new System.Windows.Forms.ListBox();
            this.tbxRegCourseName = new System.Windows.Forms.TextBox();
            this.btnRegCourseHiding = new System.Windows.Forms.Button();
            this.btnRegCourseOverriding = new System.Windows.Forms.Button();
            this.tabMain.SuspendLayout();
            this.tpgEntrance.SuspendLayout();
            this.pnlEntranceCompany.SuspendLayout();
            this.tpgRegCourse.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tpgEntrance);
            this.tabMain.Controls.Add(this.tpgRegCourse);
            this.tabMain.Controls.Add(this.tpgSearchStudent);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.ItemSize = new System.Drawing.Size(100, 35);
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(800, 450);
            this.tabMain.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabMain.TabIndex = 0;
            // 
            // tpgEntrance
            // 
            this.tpgEntrance.Controls.Add(this.cbxEntranceGrade);
            this.tpgEntrance.Controls.Add(this.btnEntrance);
            this.tpgEntrance.Controls.Add(this.pnlEntranceCompany);
            this.tpgEntrance.Controls.Add(this.chkIndustrialEdu);
            this.tpgEntrance.Controls.Add(this.tbxEntranceName);
            this.tpgEntrance.Controls.Add(this.label2);
            this.tpgEntrance.Controls.Add(this.lblEntranceResult);
            this.tpgEntrance.Controls.Add(this.label1);
            this.tpgEntrance.Location = new System.Drawing.Point(4, 39);
            this.tpgEntrance.Name = "tpgEntrance";
            this.tpgEntrance.Padding = new System.Windows.Forms.Padding(3);
            this.tpgEntrance.Size = new System.Drawing.Size(792, 407);
            this.tpgEntrance.TabIndex = 0;
            this.tpgEntrance.Text = "입학관리";
            this.tpgEntrance.UseVisualStyleBackColor = true;
            // 
            // cbxEntranceGrade
            // 
            this.cbxEntranceGrade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxEntranceGrade.FormattingEnabled = true;
            this.cbxEntranceGrade.Location = new System.Drawing.Point(162, 67);
            this.cbxEntranceGrade.Name = "cbxEntranceGrade";
            this.cbxEntranceGrade.Size = new System.Drawing.Size(198, 24);
            this.cbxEntranceGrade.TabIndex = 6;
            // 
            // btnEntrance
            // 
            this.btnEntrance.Location = new System.Drawing.Point(28, 168);
            this.btnEntrance.Name = "btnEntrance";
            this.btnEntrance.Size = new System.Drawing.Size(401, 36);
            this.btnEntrance.TabIndex = 4;
            this.btnEntrance.Text = "등록";
            this.btnEntrance.UseVisualStyleBackColor = true;
            this.btnEntrance.Click += new System.EventHandler(this.btnEntrance_Click);
            // 
            // pnlEntranceCompany
            // 
            this.pnlEntranceCompany.Controls.Add(this.tbxEntranceCompany);
            this.pnlEntranceCompany.Controls.Add(this.label3);
            this.pnlEntranceCompany.Location = new System.Drawing.Point(18, 114);
            this.pnlEntranceCompany.Name = "pnlEntranceCompany";
            this.pnlEntranceCompany.Size = new System.Drawing.Size(418, 32);
            this.pnlEntranceCompany.TabIndex = 3;
            this.pnlEntranceCompany.Visible = false;
            // 
            // tbxEntranceCompany
            // 
            this.tbxEntranceCompany.Location = new System.Drawing.Point(144, 3);
            this.tbxEntranceCompany.Name = "tbxEntranceCompany";
            this.tbxEntranceCompany.Size = new System.Drawing.Size(267, 26);
            this.tbxEntranceCompany.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(7, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 32);
            this.label3.TabIndex = 0;
            this.label3.Text = "회사";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkIndustrialEdu
            // 
            this.chkIndustrialEdu.AutoSize = true;
            this.chkIndustrialEdu.Location = new System.Drawing.Point(370, 74);
            this.chkIndustrialEdu.Name = "chkIndustrialEdu";
            this.chkIndustrialEdu.Size = new System.Drawing.Size(59, 20);
            this.chkIndustrialEdu.TabIndex = 2;
            this.chkIndustrialEdu.Text = "산학";
            this.chkIndustrialEdu.UseVisualStyleBackColor = true;
            this.chkIndustrialEdu.CheckedChanged += new System.EventHandler(this.chkIndustrialEdu_CheckedChanged);
            // 
            // tbxEntranceName
            // 
            this.tbxEntranceName.Location = new System.Drawing.Point(162, 25);
            this.tbxEntranceName.Name = "tbxEntranceName";
            this.tbxEntranceName.Size = new System.Drawing.Size(198, 26);
            this.tbxEntranceName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(25, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "학년";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblEntranceResult
            // 
            this.lblEntranceResult.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblEntranceResult.Location = new System.Drawing.Point(3, 239);
            this.lblEntranceResult.Name = "lblEntranceResult";
            this.lblEntranceResult.Padding = new System.Windows.Forms.Padding(10);
            this.lblEntranceResult.Size = new System.Drawing.Size(786, 165);
            this.lblEntranceResult.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(25, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "이름";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tpgRegCourse
            // 
            this.tpgRegCourse.Controls.Add(this.lbxRegCourse);
            this.tpgRegCourse.Controls.Add(this.btnRegCourseOverriding);
            this.tpgRegCourse.Controls.Add(this.btnRegCourseHiding);
            this.tpgRegCourse.Controls.Add(this.btnRegCourseSearch);
            this.tpgRegCourse.Controls.Add(this.tbxRegCourseName);
            this.tpgRegCourse.Controls.Add(this.tbxRegCourseSearchId);
            this.tpgRegCourse.Controls.Add(this.lblRegCourseName);
            this.tpgRegCourse.Controls.Add(this.label9);
            this.tpgRegCourse.Controls.Add(this.label7);
            this.tpgRegCourse.Controls.Add(this.lblRegCourseId);
            this.tpgRegCourse.Controls.Add(this.label5);
            this.tpgRegCourse.Controls.Add(this.label4);
            this.tpgRegCourse.Location = new System.Drawing.Point(4, 39);
            this.tpgRegCourse.Name = "tpgRegCourse";
            this.tpgRegCourse.Padding = new System.Windows.Forms.Padding(3);
            this.tpgRegCourse.Size = new System.Drawing.Size(792, 407);
            this.tpgRegCourse.TabIndex = 1;
            this.tpgRegCourse.Text = "수강관리";
            this.tpgRegCourse.UseVisualStyleBackColor = true;
            // 
            // tpgSearchStudent
            // 
            this.tpgSearchStudent.Location = new System.Drawing.Point(4, 39);
            this.tpgSearchStudent.Name = "tpgSearchStudent";
            this.tpgSearchStudent.Padding = new System.Windows.Forms.Padding(3);
            this.tpgSearchStudent.Size = new System.Drawing.Size(792, 407);
            this.tpgSearchStudent.TabIndex = 2;
            this.tpgSearchStudent.Text = "학생조회";
            this.tpgSearchStudent.UseVisualStyleBackColor = true;
            // 
            // tbxRegCourseSearchId
            // 
            this.tbxRegCourseSearchId.Location = new System.Drawing.Point(178, 30);
            this.tbxRegCourseSearchId.Name = "tbxRegCourseSearchId";
            this.tbxRegCourseSearchId.Size = new System.Drawing.Size(198, 26);
            this.tbxRegCourseSearchId.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(29, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 32);
            this.label4.TabIndex = 2;
            this.label4.Text = "학번";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(29, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 32);
            this.label5.TabIndex = 2;
            this.label5.Text = "학번";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblRegCourseId
            // 
            this.lblRegCourseId.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRegCourseId.Location = new System.Drawing.Point(178, 84);
            this.lblRegCourseId.Name = "lblRegCourseId";
            this.lblRegCourseId.Size = new System.Drawing.Size(198, 32);
            this.lblRegCourseId.TabIndex = 2;
            this.lblRegCourseId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(29, 133);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 32);
            this.label7.TabIndex = 2;
            this.label7.Text = "이름";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblRegCourseName
            // 
            this.lblRegCourseName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRegCourseName.Location = new System.Drawing.Point(178, 133);
            this.lblRegCourseName.Name = "lblRegCourseName";
            this.lblRegCourseName.Size = new System.Drawing.Size(198, 32);
            this.lblRegCourseName.TabIndex = 2;
            this.lblRegCourseName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(29, 182);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(118, 32);
            this.label9.TabIndex = 2;
            this.label9.Text = "수강과목";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnRegCourseSearch
            // 
            this.btnRegCourseSearch.Location = new System.Drawing.Point(393, 25);
            this.btnRegCourseSearch.Name = "btnRegCourseSearch";
            this.btnRegCourseSearch.Size = new System.Drawing.Size(105, 36);
            this.btnRegCourseSearch.TabIndex = 5;
            this.btnRegCourseSearch.Text = "검색";
            this.btnRegCourseSearch.UseVisualStyleBackColor = true;
            this.btnRegCourseSearch.Click += new System.EventHandler(this.btnRegCourseSearch_Click);
            // 
            // lbxRegCourse
            // 
            this.lbxRegCourse.FormattingEnabled = true;
            this.lbxRegCourse.ItemHeight = 16;
            this.lbxRegCourse.Location = new System.Drawing.Point(178, 182);
            this.lbxRegCourse.Name = "lbxRegCourse";
            this.lbxRegCourse.Size = new System.Drawing.Size(198, 164);
            this.lbxRegCourse.TabIndex = 6;
            // 
            // tbxRegCourseName
            // 
            this.tbxRegCourseName.Location = new System.Drawing.Point(178, 352);
            this.tbxRegCourseName.Name = "tbxRegCourseName";
            this.tbxRegCourseName.Size = new System.Drawing.Size(198, 26);
            this.tbxRegCourseName.TabIndex = 3;
            // 
            // btnRegCourseHiding
            // 
            this.btnRegCourseHiding.Location = new System.Drawing.Point(393, 347);
            this.btnRegCourseHiding.Name = "btnRegCourseHiding";
            this.btnRegCourseHiding.Size = new System.Drawing.Size(149, 36);
            this.btnRegCourseHiding.TabIndex = 5;
            this.btnRegCourseHiding.Text = "등록(하이딩)";
            this.btnRegCourseHiding.UseVisualStyleBackColor = true;
            this.btnRegCourseHiding.Click += new System.EventHandler(this.btnRegCourseHiding_Click);
            // 
            // btnRegCourseOverriding
            // 
            this.btnRegCourseOverriding.Location = new System.Drawing.Point(548, 347);
            this.btnRegCourseOverriding.Name = "btnRegCourseOverriding";
            this.btnRegCourseOverriding.Size = new System.Drawing.Size(149, 36);
            this.btnRegCourseOverriding.TabIndex = 5;
            this.btnRegCourseOverriding.Text = "등록(오버라이딩)";
            this.btnRegCourseOverriding.UseVisualStyleBackColor = true;
            this.btnRegCourseOverriding.Click += new System.EventHandler(this.btnRegCourseOverriding_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabMain);
            this.Font = new System.Drawing.Font("굴림", 12F);
            this.Name = "Form1";
            this.Text = "학생관리";
            this.tabMain.ResumeLayout(false);
            this.tpgEntrance.ResumeLayout(false);
            this.tpgEntrance.PerformLayout();
            this.pnlEntranceCompany.ResumeLayout(false);
            this.pnlEntranceCompany.PerformLayout();
            this.tpgRegCourse.ResumeLayout(false);
            this.tpgRegCourse.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tpgEntrance;
        private System.Windows.Forms.TabPage tpgRegCourse;
        private System.Windows.Forms.ComboBox cbxEntranceGrade;
        private System.Windows.Forms.Button btnEntrance;
        private System.Windows.Forms.Panel pnlEntranceCompany;
        private System.Windows.Forms.TextBox tbxEntranceCompany;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkIndustrialEdu;
        private System.Windows.Forms.TextBox tbxEntranceName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblEntranceResult;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tpgSearchStudent;
        private System.Windows.Forms.ListBox lbxRegCourse;
        private System.Windows.Forms.Button btnRegCourseOverriding;
        private System.Windows.Forms.Button btnRegCourseHiding;
        private System.Windows.Forms.Button btnRegCourseSearch;
        private System.Windows.Forms.TextBox tbxRegCourseName;
        private System.Windows.Forms.TextBox tbxRegCourseSearchId;
        private System.Windows.Forms.Label lblRegCourseName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblRegCourseId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}

