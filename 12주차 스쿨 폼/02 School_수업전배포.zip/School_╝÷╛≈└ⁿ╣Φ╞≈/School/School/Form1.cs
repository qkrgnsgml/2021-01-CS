﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School
{
    public partial class Form1 : Form
    {
        const int MAX_GRADE = 4;
        List<Student> _students;
        Student _studentRegCourse = null;

        public Form1()
        {
            InitializeComponent();

            _students = new List<Student>();

            for (int i = 1; i <= MAX_GRADE; i++)
            {
                cbxEntranceGrade.Items.Add(i.ToString());
            }
            cbxEntranceGrade.SelectedIndex = 0;
        }

        private void chkIndustrialEdu_CheckedChanged(object sender, EventArgs e)
        {
            pnlEntranceCompany.Visible = chkIndustrialEdu.Checked;
        }

        private void btnEntrance_Click(object sender, EventArgs e)
        {
            string temp_str = null;
            int temp_int = 0;

            int grade = 1;
            int.TryParse(cbxEntranceGrade.SelectedItem.ToString(), out grade);

            int year = DateTime.Now.Year - (grade - 1);
            string id = string.Empty;
            if (_students != null && _students.Count > 0)
            {
                temp_str = year.ToString("0000");
                temp_str = _students.Where(m => m.Id.StartsWith(temp_str))
                                .OrderByDescending(m => m.Id)
                                .Select(m => m.Id)
                                .FirstOrDefault();

                if (string.IsNullOrEmpty(temp_str))
                {
                    id = $"{year:0000}0001";
                }
                else
                {
                    int.TryParse(temp_str.Substring(4, 4), out temp_int);
                    id = id = $"{year:0000}{temp_int + 1:0000}";
                }
            }
            else
            {
                id = $"{year:0000}0001";
            }

            Student student = null;
            if (chkIndustrialEdu.Checked)
            {
                student = new StudentIndustrialEdu(tbxEntranceName.Text, id, grade, tbxEntranceCompany.Text);
            }
            else
            {
                student = new Student(tbxEntranceName.Text, id, grade);
            }
            _students.Add(student);

            lblEntranceResult.Text
                = $"등록학생의 정보입니다.\r\n학번 : {student.Id}\r\n이름 : {student.Name}\r\n학년 : {student.Grade}\r\n";

            //Type1
            //if(student is StudentIndustrialEdu)
            //{
            //    temp_str = ((StudentIndustrialEdu)student).Company;
            //    lblEntranceResult.Text += $"[산학과정] 소속회사:{temp_str}";
            //}

            //Type2
            StudentIndustrialEdu studentIE = student as StudentIndustrialEdu;
            if (studentIE != null)
            {
                lblEntranceResult.Text += $"[산학과정] 소속회사:{studentIE.Company}";
            }
        }

        private void btnRegCourseSearch_Click(object sender, EventArgs e)
        {
            if (_students == null || _students.Count <= 0)
            {
                MessageBox.Show("검색할 학생이 없습니다.");
                return;
            }

            _studentRegCourse = null;
            foreach (var stu in _students)
            {
                if (stu.Id == tbxRegCourseSearchId.Text)
                {
                    _studentRegCourse = stu;
                    break;
                }
            }

            if (_studentRegCourse == null)
            {
                lblRegCourseId.Text = string.Empty;
                lblRegCourseName.Text = string.Empty;
                lbxRegCourse.Items.Clear();

                MessageBox.Show("해당 학생을 찾을 수 없습니다.");
            }
            else
            {
                lblRegCourseId.Text = _studentRegCourse.Id;
                lblRegCourseName.Text = _studentRegCourse.Name;
                lbxRegCourse.Items.Clear();
                foreach (var sub in _studentRegCourse.Subject)
                {
                    lbxRegCourse.Items.Add(sub);
                }
            }
        }

        private void btnRegCourseHiding_Click(object sender, EventArgs e)
        {
            if (_studentRegCourse != null)
            {
                if (_studentRegCourse.RegCourse(tbxRegCourseName.Text))//hiding
                {
                    lbxRegCourse.Items.Add(tbxRegCourseName.Text);
                }
                else
                {
                    MessageBox.Show("등록실패");
                }
            }
        }

        private void btnRegCourseOverriding_Click(object sender, EventArgs e)
        {
            if (_studentRegCourse != null)
            {
                if (_studentRegCourse.RegCourseEx(tbxRegCourseName.Text))//overridng**
                {
                    lbxRegCourse.Items.Add(tbxRegCourseName.Text);
                }
                else
                {
                    MessageBox.Show("등록실패");
                }
            }
        }
    }
}
